export declare var fetch: typeof globalThis.fetch;
export declare var Headers: typeof globalThis.Headers;
export declare var Request: typeof globalThis.Request;
export declare var Response: typeof globalThis.Response;
